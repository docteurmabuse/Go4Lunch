package com.tizzone.go4lunch.base;

import android.view.View;

public class MyHandlers {
    public void onClickLogout(View view) {

    }
}
